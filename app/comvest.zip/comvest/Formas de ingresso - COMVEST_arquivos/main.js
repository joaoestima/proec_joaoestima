jQuery(document).ready(function(){
	jQuery(".fontResizer").fontresizermanager();
});
