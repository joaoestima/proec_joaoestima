/**
 * Scripts customizados
 *
**/

function remeter(z) {
      if (z.value != "Selecione"){
             var b = '/estatisticas/'+z.value+'/quest/quest1.php'; window.location=b;
       }
}

function Insc_oficina(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao/inscricao.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_oficina(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_oficina(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Insc_oficina_itinerante(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao_itinerante/inscricao.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_oficina_itinerante(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao_itinerante/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_oficina_itinerante(){
     cyber=window.open('https://www.comvest.unicamp.br/oficina_redacao_itinerante/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_isencao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/isencao/inscricao/isencao0.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_isencao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/isencao/inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_isencao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/isencao/inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_isencao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/isencao/inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Insc_encontro(){
     cyber=window.open('https://www.comvest.unicamp.br/encontro_prof/inscricao.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_encontro(){
     cyber=window.open('https://www.comvest.unicamp.br/encontro_prof/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_encontro(){
     cyber=window.open('https://www.comvest.unicamp.br/encontro_prof/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/insc_normal.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Insc_Isento_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/insc_isento.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Insc_Reducao_vestibular(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/inscricao/insc_reducao.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_reducao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/reducao_parcial/inscricao/index.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_reducao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/reducao_parcial/inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_reducao(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/reducao_parcial/inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_reducao(){     
	cyber=window.open('https://www.comvest.unicamp.br/vest2021/reducao_parcial/inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_vr(){
     cyber=window.open('https://www.comvest.unicamp.br/vr/vr2021/inscricao/insc_normal.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_vr(){
     cyber=window.open('https://www.comvest.unicamp.br/vr/vr2021/inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_vr(){
     cyber=window.open('https://www.comvest.unicamp.br/vr/vr2021/inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_vr(){
     cyber=window.open('https://www.comvest.unicamp.br/vr/vr2021/inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_vi(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vi/vi_inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_vi(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vi/vi_inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_vi(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vi/vi_inscricao/insc_normal.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_vi(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vi/vi_inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_ve(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/ve/ve_inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_ve(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/ve/ve_inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_ve(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/ve/ve_inscricao/insc_normal.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Insc_Isento_ve(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/ve/ve_inscricao/insc_isento.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_ve(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/ve/ve_inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Status_vo(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vo/vo_inscricao/consulta.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Alterar_vo(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vo/vo_inscricao/alterar.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Inscricao_vo(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vo/vo_inscricao/insc_normal.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

function Via2_vo(){
     cyber=window.open('https://www.comvest.unicamp.br/vest2021/vo/vo_inscricao/via2.php','Comvest','toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,maximized=yes')
}

